package com.thingworx.sdk.practise;

import com.thingworx.communications.client.ConnectedThingClient;
import com.thingworx.communications.client.things.VirtualThing;

public class FileTransferThing extends VirtualThing{

	public FileTransferThing(String FileTransferThing, String description, ConnectedThingClient client) {
		// TODO Auto-generated constructor stub
		super(FileTransferThing,description,client);
	}

}
